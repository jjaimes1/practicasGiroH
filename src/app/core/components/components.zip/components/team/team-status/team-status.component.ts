import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-team-status',
  templateUrl: './team-status.component.html',
  styleUrls: ['./team-status.component.css']
})
export class TeamStatusComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
