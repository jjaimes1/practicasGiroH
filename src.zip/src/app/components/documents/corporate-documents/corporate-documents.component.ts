import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-corporate-documents',
  templateUrl: './corporate-documents.component.html',
  styleUrls: ['./corporate-documents.component.css']
})
export class CorporateDocumentsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
