import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-self-attendance',
  templateUrl: './self-attendance.component.html',
  styleUrls: ['./self-attendance.component.css']
})
export class SelfAttendanceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
