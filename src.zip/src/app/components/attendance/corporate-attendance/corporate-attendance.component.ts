import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-corporate-attendance',
  templateUrl: './corporate-attendance.component.html',
  styleUrls: ['./corporate-attendance.component.css'],
})
export class CorporateAttendanceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {

  }
}