import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-planificar',
  templateUrl: './planificar.component.html',
  styleUrls: ['./planificar.component.css']
})
export class PlanificarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
