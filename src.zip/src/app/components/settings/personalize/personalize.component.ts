import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-personalize',
  templateUrl: './personalize.component.html',
  styleUrls: ['./personalize.component.css']
})
export class PersonalizeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
