import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-setting-roles',
  templateUrl: './setting-roles.component.html',
  styleUrls: ['./setting-roles.component.css']
})
export class SettingRolesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
