import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-team-roles',
  templateUrl: './team-roles.component.html',
  styleUrls: ['./team-roles.component.css']
})
export class TeamRolesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
