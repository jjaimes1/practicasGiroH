import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-contact-detail',
  templateUrl: './page-contact-detail.component.html',
  styleUrls: ['./page-contact-detail.component.css']
})
export class PageContactDetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
