import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-blog-sidebar',
  templateUrl: './page-blog-sidebar.component.html',
  styleUrls: ['./page-blog-sidebar.component.css']
})
export class PageBlogSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
