import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shop-checkouts',
  templateUrl: './shop-checkouts.component.html',
  styleUrls: ['./shop-checkouts.component.css']
})
export class ShopCheckoutsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
