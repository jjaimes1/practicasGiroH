import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-blog-list-sidebar',
  templateUrl: './page-blog-list-sidebar.component.html',
  styleUrls: ['./page-blog-list-sidebar.component.css']
})
export class PageBlogListSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }



}
