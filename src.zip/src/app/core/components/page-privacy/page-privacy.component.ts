import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-privacy',
  templateUrl: './page-privacy.component.html',
  styleUrls: ['./page-privacy.component.css']
})
export class PagePrivacyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
