import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-blog-detail-two',
  templateUrl: './page-blog-detail-two.component.html',
  styleUrls: ['./page-blog-detail-two.component.css']
})
export class PageBlogDetailTwoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }


}
