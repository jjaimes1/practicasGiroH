import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-contact-three',
  templateUrl: './page-contact-three.component.html',
  styleUrls: ['./page-contact-three.component.css']
})
export class PageContactThreeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
